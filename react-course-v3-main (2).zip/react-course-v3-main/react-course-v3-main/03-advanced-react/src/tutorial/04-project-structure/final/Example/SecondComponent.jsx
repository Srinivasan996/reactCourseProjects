const SecondComponent = () => {
  return <div>SecondComponent</div>;
};
export default SecondComponent;
