const App = () => {
  return <h2>Accordion Starter</h2>;
};
export default App;
