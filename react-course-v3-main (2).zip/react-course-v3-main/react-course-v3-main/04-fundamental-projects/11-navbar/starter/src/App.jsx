const App = () => {
  return <h2>Navbar Starter</h2>;
};
export default App;
