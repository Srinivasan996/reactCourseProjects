const App = () => {
  return <h2>Birthday Reminder - Starter</h2>;
};
export default App;
