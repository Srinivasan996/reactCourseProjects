const App = () => {
  return <h2>Reviews Starter</h2>;
};
export default App;
