const App = () => {
  return <h1>Contentful Starter</h1>;
};
export default App;
